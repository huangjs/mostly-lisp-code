// Global VM registers

var scope = [];
// Scope is an array of values
// for local variables.
// An ir_var_scope w/ index = i
// evaluates to scope[i];
var args  = [];
// Args is an array of values for
// arguments or the returned value
// Same deal w/ ir_var_args
var cont  = [];
// Cont is a stack of Cont_frame
// Only ir_bind (which introduces
// non-tail-calls) should push
// onto it. 
// Return consists of poping
// a frame, and reinstating
// the scope (scope = frame.env)
// and the code to execute
// (expr = frame.body)
// simply set expr to null
// if there's nothing left
// to do.
var expr  = null;
// PC. The expression that's
// being evaled, or the 
// expression to evaluate.
var process = null;
// Current process. 


// Global -> value dictionary
var globals = {};
// String -> interned symbol
// dictionary
var symbol_table = {};

// Process queue for the scheduler
// queue (push/shift) of Process
var process_queue = [];

// Table of process ID -> Process/Host
// Host : a String
var process_table = {};

// Should be ok, even w/o bignums
var uid_counter = 0;

// Overwritten by index.scm
var node_name = "NODE";

function Cont_frame (env, body)
{
	this.env  = env;
	this.body = body;
}

// Serialisation == toSource().
// We just eval on reception.
Cont_frame.prototype.toSource = function () {
	return "new Cont_frame("+this.env.toSource()+", " 
	                        +this.body.toSource() +")";
};

// Overwritten by index.scm
function sendToServer(x)
{
	print("send " + x);
}


// Printing/serialisation noise
function toScheme (obj)
{
	if (null === obj)
		return "()";

	if (false === obj)
		return "#f";

	if (true === obj)
		return "#t";

	if (null != obj.toScheme)
		return obj.toScheme();

	if (null != obj.toString)
		return obj.toString();

	return ""+obj; // default casting rules
}

if (null == Object.prototype.toString) {
	Object.prototype.toString = function () {
		return "[Object object]";
	};
}

if (null == String.prototype.toSource) {
	Object.prototype.toString = function () {
		return "(new String(\"" +this+ "\"))";
	};
}

String.prototype.toScheme = function() {
	return "\"" + this.toString() + "\"";
};

if (null == Object.prototype.toSource) {
	Object.prototype.toSource = function () {
		str = "{";
		var first = true;

		for (var i in this) {
			if (!(this[i] instanceof Function)) {
				if (!first)
					str += ", ";

				str += "\"" + i + "\": " 
					+ this[i].toSource;
			}
		}

		return str+"}";
	};
}

if (null == Array.prototype.toSource) {
	Array.prototype.toSource = function () {
		var str = "[";
		var first = true;

		for (var i = 0; i < this.length; i++) {
			if (!first)
				str += ", ";
			if (null != this[i]) {
				str += this[i].toSource();
			} else {
				str += "null"
			}

			first = false;
		}
		return str + "]"
	};
}

function make_uid (uid)
{
	if (null == uid)
		var uid = ++uid_counter;

	return new String(node_name+":"+uid);
}


// Find the node for a descriptor
// simply return everything before
// the first colon.
function descriptor_node (descriptor)
{
	var split = descriptor.search(":");
	if (split < 0)
		return false;

	return new String(descriptor.substr(0, split));
}

// A process has
// a uid (String)
// mailbox: queue (JS array)
// args: copy of the `args' global
// env:  copy of the `scope' global
// expr: copy of the `expr' global
// continuation: cont
// status: null -> ready
//         true -> waiting for a message
//         Date -> waiting until that date
function Process (uid, mailbox, args, env, expr, continuation, status)
{
	if (!(uid instanceof String))
		uid = make_uid(uid);

	if (null == mailbox)
		mailbox = [];

	if (null == args)
		args = [];

	if (null == env)
		env = scope.slice(0);

	if (null == continuation)
		continuation = cont.slice(0);

	this.uid     = uid;
	this.mailbox = mailbox;
	this.args    = args;
	this.env     = env;
	this.expr    = expr;
	this.cont    = continuation;
	this.status  = status;

	process_table[uid] = this;
}

function safeToSource (x)
{
	if (null === x)
		return "null";

	return x.toSource();
}

function safeToString (x)
{
	if (null === x)
		return "null";

	return x.toString();
}

Process.prototype.toSource = function () {
	return "new Process(new String(\""+this.uid+"\"), "
	                   +this.mailbox.toSource()+","
	                   +this.args.toSource()+", "
	                   +this.env.toSource()+", "
	                   +safeToSource(this.expr)+", "
                           +this.cont.toSource()+", "
	                   +safeToSource(this.status)+")";
};

function Symbol (name)
{
	this.name = name;
}

Symbol.prototype.toSource = function () {
	return "make_symbol(\"" + this.name + "\")";
};

Symbol.prototype.toString = function () {
	return "'"+this.name;
};

Symbol.prototype.toScheme = function () {
	return this.name;
};

function make_symbol (name)
{
	if (symbol_table[name] != null)
		return symbol_table[name];

	var symbol = new Symbol(name);
	symbol_table[name] = symbol;

	return symbol;
}

function Cons (car, cdr)
{
	this.car = car;
	this.cdr = cdr;
}

Cons.prototype.toSource = function () {
	return "new Cons("+safeToSource(this.car)+", "
	                  +safeToSource(this.cdr)+")";
};

Cons.prototype.toString = function () {
	return "(" + safeToString(this.car) + " . " 
	           + safeToString(this.cdr)+")";
};

Cons.prototype.toScheme = function () {
	var str = "(" + toScheme(this.car);
	
	var cons;

	for (cons = this.cdr; 
	     cons instanceof Cons; 
	     cons = cons.cdr)
		str += " " + toScheme(cons.car);

	if (null === cons)
		return str + ")";

	return str + " . " + toScheme(cons) + ")";
};

// JS array -> list
function to_list (arr)
{
	var list = null;
	for (var i = arr.length - 1; i >= 0; i--)
		list = new Cons (arr[i], list);

	return list;
}

// build the expression (string)
// that copies indices the values
// in the right indices of scope
// and args into a new array.
function make_make_closure (from_scope, from_args)
{
	var expr = "[";
	var first = true;
	var i;

	for (i = 0; i < from_scope.length; i++) {
		if (!first) {
			expr += ", ";
		}
		first = false;
		expr += "scope["+from_scope[i]+"]";
	}

	for (i = 0; i < from_args.length; i++) {
		if (!first) {
			expr += ", ";
		}
		first = false;
		expr += "args["+from_args[i]+"]";
	}

	expr += "]";

	return expr;
}

function ir_bind (from_scope, from_args, val, expr)
{
	this.from_scope = from_scope;
	this.from_args  = from_args;
	this.val        = val;
	this.expr       = expr;
	if (null != from_scope) {
		this.fn = eval("(function () { "
			       + "scope = " 
			           + make_make_closure(from_scope, from_args)
			           + ";"
			       + "cont.push(new Cont_frame(scope, "
                                                         +"this.expr));"
			       + "this.val.fn();"
			       + "});");
	}
}

// fn is what the VM calls to execute
// an instruction
// bind introduces non-tail calls
// so must push a new frame on the cont
ir_bind.prototype.fn = function () {
	cont.push(new Cont_frame(scope, this.expr));
	this.val.fn();
};

ir_bind.prototype.toSource = function () {
	return "new ir_bind(" + safeToSource(this.from_scope)
	                      + ", "
	                      + safeToSource(this.from_args)
	                      + ", "
	                      + this.val.toSource() + ", "
		              + this.expr.toSource() + ")";
};

// literal
function ir_lit (lit)
{
	this.lit = lit;
}

ir_lit.prototype.lookup = function () {
	return this.lit;
}

ir_lit.prototype.fn = function () {
	args.length = 1;
	args[0] = this.lit;
	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr = null;
	}
};

ir_lit.prototype.toSource = function () {
	return "new ir_lit(" + safeToSource(this.lit) + ")";
};

// reference to a global
function ir_glo (name)
{
	this.name = name;
}

ir_glo.prototype.lookup = function () {
	return globals[this.name];
};

ir_glo.prototype.fn = function () {
	args.length = 1;
	args[0] = globals[this.name];
	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr = null;
	}
};

ir_glo.prototype.toSource = function () {
	return "new ir_glo(\"" + this.name + "\")";
};

// reference to a lexical var
// in `scope'
function ir_var_scope (index)
{
	this.index = index;
}

ir_var_scope.prototype.lookup = function () {
	return scope[this.index];
};

ir_var_scope.prototype.fn = function () {
	args.length = 1;
	args[0] = scope[this.index];
	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr = null;
	}
};

ir_var_scope.prototype.toSource = function () {
	return "new ir_var_scope(" + this.index + ")";
};

// reference to a lexical var
// in `args'
function ir_var_args (index)
{
	this.index = index;
}

ir_var_args.prototype.lookup = function () {
	return args[this.index];
};

ir_var_args.prototype.fn = function () {
	args.length = 1;
	args[0] = args[this.index];
	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr = null;
	}
};

ir_var_args.prototype.toSource = function () {
	return "new ir_var_args(" + this.index + ")";
};

// lambda; return a new closure
// on evaluation
function ir_lambda (from_scope, from_args, num_posn_args, varargp, body)
{
	this.from_scope = from_scope;
	this.from_args  = from_args;
	this.num_posn_args = num_posn_args;
	this.varargp = varargp;
	this.body = body;
	if (null != from_scope) {
		this.fn = eval("(function () {"
			       + "args.length = 1;"
			       + "args[0] = new ir_closure("
			                         + make_make_closure(from_scope, from_args) + ", "
			                         + num_posn_args + ", "
			                         + varargp + ", "
                                                 + "this.body);"
			       + "if (cont.length > 0) {"
			       + "   var frame = cont.pop();"
			       + "   scope = frame.env;"
			       + "   expr  = frame.body;"
			       + "} else {"
			       + "   expr  = null;"
			       + "}"
			       + "});");
	}
}

// default caller; we just keep the
// same `scope'
ir_lambda.prototype.fn = function () {
	args.length = 1;
	args[0] = new ir_closure(scope, 
				 this.num_posn_args,
				 this.varargp,
				 this.body);

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

ir_lambda.prototype.toSource = function () {
	return "new ir_lambda(" + safeToSource(this.from_scope)
	                        + ", "
	                        + safeToSource(this.from_args)
	                        + ", "
	                        + this.num_posn_args + ", "
	                        + this.varargp + ", "
	                        + this.body.toSource() + ")";
};

// a closure -- shouldn't be in an expression
// itself, but should be callable
function ir_closure (env, num_posn_args, varargp, body) {
	this.env = env;
	this.num_posn_args = num_posn_args;
	this.varargp = varargp;
	this.body = body;
	if (varargp) {
		this.invoke = ir_closure_vararg_invoke;
	}
}

function ir_closure_vararg_invoke (fn_args) {
	if (fn_args.length < this.num_posn_args) {
		print("not enough arguments!\n");
		expr = null;
		return;
	}

	args = fn_args.slice(0, fn.num_args);
	args.push(to_list(fn_args.slice(fn.num_args)));

	scope = this.env;
	expr = this.body;
}

ir_closure.prototype.invoke = function (fn_args) {
	if (fn_args.length != this.num_posn_args) {
		print("wrong number of arguments!\n" + fn_args.toSource());
		expr = null;
		return;
	}
	
	args = fn_args;
	scope = this.env;
	expr = this.body;
};

ir_closure.prototype.toSource = function () {
	return "new ir_closure(" + this.env.toSource() + ", "
	                         + this.num_posn_args  + ", "
	                         + this.varargp        + ", "
	                         + this.body.toSource() + ")";
};

ir_closure.prototype.toString = function () {
	return "[Closure]";
};

ir_closure.prototype.toScheme = function () {
	return "<Closure>";
};

// if of a global
function ir_if_glo (name, then, alt)
{
	this.name = name;
	this.then = then;
	this.alt  = alt;
}

ir_if_glo.prototype.fn = function () {
	if (false != globals[this.name]) {
		expr = this.then;
	} else {
		expr = this.alt;
	}
};

ir_if_glo.prototype.toSource = function () {
	return "new ir_if_glo(\"" + this.name + "\", "
	                          + this.then.toSource() + ", "
	                          + this.alt.toSource() +")";
};

// if of a var in scope
function ir_if_scope (index, then, alt)
{
	this.index = index;
	this.then  = then;
	this.alt   = alt;
}

ir_if_scope.prototype.fn = function () {
	if (false != scope[this.index]) {
		expr = this.then;
	} else {
		expr = this.alt;
	}
};

ir_if_scope.prototype.toSource = function () {
	return "new ir_if_scope(" + this.index + ", "
	                          + this.then.toSource() + ","
	                          + this.alt.toSource() + ")";
};

// if of a var in args
function ir_if_args (index, then, alt)
{
	this.index = index;
	this.then  = then;
	this.alt   = alt;
}

ir_if_args.prototype.fn = function () {
	if (false != args[this.index]) {
		expr = this.then;
	} else {
		expr = this.alt;
	}
};

ir_if_args.prototype.toSource = function () {
	return "new ir_if_args(" + this.index + ", "
	                         + this.then.toSource() + ","
	                         + this.alt.toSource() + ")";
};

function make_make_arg_values (args) 
{
	var expr = "[";
	var first = true;
	var i;
	
	for (i = 0; i < args.length; i++) {
		if (!first) {
			expr += ", ";
		}
		first = false;
		expr += "this.args["+i+"].lookup()";
	}

	expr += "]";

	return expr;
}

// call to `fun'
function ir_call (fun, args) 
{
	this.fun = fun;
	this.args = args;

	this.fn = eval("(function () { "
		+ "var fun = this.fun.lookup(); "
		+ "var arg_values = " + make_make_arg_values(args) + "; " // can't make this non consing :(
		+ "if (fun instanceof Function) { "
		+ "   fun.apply(fun, arg_values); "
		+ "} else { "
		+ "   fun.invoke(arg_values); "
		+ "} "
		+ "});");
}

ir_call.prototype.toSource = function () {
	return "new ir_call(" + this.fun.toSource() + ", "
	                      + this.args.toSource() + ")";
};

// call to a primop
function ir_primop (primop, fn_args)
{
	this.primop = primop;
	this.fn_args = fn_args;
	this.fn = primops[primop];

	if (null != this.fn.fixup)
		this.fn.fixup(this, fn_args);
}

ir_primop.prototype.toSource = function () {
	return "new ir_primop(\"" + this.primop + "\", "
	                          + this.fn_args.toSource() + ")";
};

// this is looked up when the expression
// is built.
var primops = [];

primops["+"] = function () {
	var sum = 0;
	var i;
	for (i = 0; i < this.fn_args.length; i++)
		sum += this.fn_args[i].lookup();

	args.length = 1;
	args[0] = sum;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["-"] = function () {
	if (0 == this.fn_args.length) {
		print("Error -- wrong number of arguments to -\n");
		expr = null;
		return;
	} else if (1 == this.fn_args.length) {
		args.length = 1;
		args[0] = - this.fn_args[0].lookup();
	} else {
		var total = this.fn_args[0].lookup();
		var i;

		for (i = 1; i < this.fn_args.length; i++)
			total -= this.fn_args[i].lookup();

		args.length = 1;
		args[0] = total;
	}

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["*"] = function () {
	var prod = 1;
	var i;
	for (i = 0; i < this.fn_args.length; i++)
		prod *= this.fn_args[i].lookup();

	args.length = 1;
	args[0] = prod;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["/"] = function () {
	if (0 == this.fn_args.length) {
		print("Error -- wrong number of arguments to /\n");
		expr = null;
		return;
	} else if (1 == this.fn_args.length) {
		args.length = 1;
		args[0] = 1 / this.fn_args[0].lookup();
	} else {
		var total = this.fn_args[0].lookup();
		var i;

		for (i = 1; i < this.fn_args.length; i++)
			total /= this.fn_args[i].lookup();

		args.length = 1;
		args[0] = total;
	}

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["cons"] = function () {
	if (2 != this.fn_args.length) {
		print("error -- wrong number of args to cons");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = new Cons(this.fn_args[0].lookup(),
			   this.fn_args[1].lookup());

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["car"] = function () {
	if (1 != this.fn_args.length) {
		print("error -- wrong number of args to car");
		expr = null;
		return;
	}

	var cons = this.fn_args[0].lookup();

	if (!(cons instanceof Cons)) {
		print("error -- car must be passed a cons");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = cons.car;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["cdr"] = function () {
	if (1 != this.fn_args.length) {
		print("error -- wrong number of args to cdr");
		expr = null;
		return;
	}

	var cons = this.fn_args[0].lookup();

	if (!(cons instanceof Cons)) {
		print("error -- cdr must be passed a cons");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = cons.cdr;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["<="] = function () {
	var result = true;
	var last = null;
	var i;
	
	for (i = 0; i < this.fn_args.length; i++) {
		var val = this.fn_args[i].lookup();

		if ((null == last) || (last <= val)) {
			last = val;
		} else {
			result = false;
			break;
		}
	}

	args.length = 1;
	args[0] = result;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["<"] = function () {
	var result = true;
	var last = null;
	var i;
	
	for (i = 0; i < this.fn_args.length; i++) {
		var val = this.fn_args[i].lookup();

		if ((null == last) || (last < val)) {
			last = val;
		} else {
			result = false;
			break;
		}
	}

	args.length = 1;
	args[0] = result;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops[">"] = function () {
	var result = true;
	var last = null;
	var i;
	
	for (i = 0; i < this.fn_args.length; i++) {
		var val = this.fn_args[i].lookup();

		if ((null == last) || (last > val)) {
			last = val;
		} else {
			result = false;
			break;
		}
	}

	args.length = 1;
	args[0] = result;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops[">="] = function () {
	var result = true;
	var last = null;
	var i;
	
	for (i = 0; i < this.fn_args.length; i++) {
		var val = this.fn_args[i].lookup();

		if ((null == last) || (last >= val)) {
			last = val;
		} else {
			result = false;
			break;
		}
	}

	args.length = 1;
	args[0] = result;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["="] = function () {
	var result = true;
	var last = null;
	var i;
	
	for (i = 0; i < this.fn_args.length; i++) {
		var val = this.fn_args[i].lookup();

		if ((null == last) || (last == val)) {
			last = val;
		} else {
			result = false;
			break;
		}
	}

	args.length = 1;
	args[0] = result;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["eq?"] = function () {
	if (2 != this.fn_args.length) {
		print("error -- wrong number of args to eq?");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = this.fn_args[0].lookup() === this.fn_args[1].lookup();

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["null?"] = function () {
	if (1 != this.fn_args.length) {
		print("error -- wrong number of args to null?");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = (null === this.fn_args[0].lookup());

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["pair?"] = function () {
	if (1 != this.fn_args.length) {
		print("error -- wrong number of args to pair?");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = (this.fn_args[0].lookup() instanceof Cons);

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

function Continuation (_cont)
{
	if (null != _cont) {
		this.cont = _cont;
	} else {
		this.cont = cont.slice(0);
	}
}

Continuation.prototype.invoke = function (cont_args) {
	if (1 != cont_args.length) {
		print("Wrong number of args passed to continuation");
		expr = null;
		return;
	}

	args = cont_args;
	cont = this.cont.slice(0);

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

Continuation.prototype.toSource = function () {
	return "new Continuation(" + this.cont.toSource() + ")";
};

primops["call/cc"] = function () {
	if (1 != this.fn_args.length) {
		print("wrong number of arguments to call/cc\n");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = new Continuation(cont.slice(0));
	this.fn_args[0].lookup().invoke(args);
};

primops["call-with-current-continuation"] = primops["call/cc"];

primops["apply"] = function () {
	if (this.fn_args.length < 2) {
		print("wrong number of arguments to apply\n")
		expr = null;
		return;
	}

	var new_args = new Array(this.fn_args.length - 2);
	var i;

	for (i = 1; i < this.fn_args.length - 1; i++)
		new_args[i-1] = this.fn_args[i].lookup();

	var last = this.fn_args[this.fn_args.length - 1].lookup();

	for (; last != null; last = last.cdr)
		new_args.push(last.car);

	this.fn_args[0].lookup().invoke(new_args);
};

primops["print"] = function () {
	if (1 != this.fn_args.length) {
		print("error -- wrong number of args to print");
		expr = null;
		return;
	}

	var obj = this.fn_args[0].lookup();

	print(toScheme(obj));

	args.length = 1;
	args[0] = null;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["spawn"] = function () {
	if (this.fn_args.length != 1) {
		print("wrong number of arguments to spawn");
		expr = null;
		return;
	}

	var proc = new Process(null, null,
			       args.slice(0), scope,
			       this.fn_args[0].lookup(), 
			       []);

	process_queue.push(proc);

	args.length = 1;
	args[0] = proc.uid;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

primops["die"] = function () {
	if (this.fn_args.length != 0) {
		print("wrong number of arguments to die");
		expr = null;
		return;
	}

	process_table[process.uid] = new String("");

	expr = null;
};

primops["yield"] = function () {
	if (this.fn_args.length != 0) {
		print("wrong number of arguments to die");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = null;

	process.expr  = null;
	process.cont  = cont;
	process.scope = scope;
	process.args  = args;
	process_queue.push(process);
	
	expr = null;
};

primops["self"] = function () {
	if (this.fn_args.length != 0) {
		print("wrong number of arguments to self");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = process.uid;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}	
};

primops["node"] = function () {
	if (this.fn_args.length != 0) {
		print("wrong number of arguments to node");
		expr = null;
		return;
	}

	args.length = 1;
	args[0] = node_name;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}	
};

// communication functions
function send (dest, msg)
{
	var server = process_table[dest];
	
	if (null == server)
		server = descriptor_node(dest);

	if (server instanceof Process) {
		server.mailbox.push(msg);
	} else if (server == node_name) { // going around in circles.
		process_table[dest] = new String(""); // He's dead Jim
	} else if (server instanceof String &&
		   server != node_name && // don't send to seld
		   server != "") {        // nor to /dev/null
// DEMO
//		alert("send to " + server.toSource());
		sendToServer("send " + server
			     +" " + "receive_msg("+node_name.toSource()+", "
			                          +dest.toSource()+" ,"
			                          +msg.toSource()+")\n");
	}
}

// used to make another node fix its
// process_table
function fix_location (uid, node)
{
// DEMO
//	alert("fixed location for uid " + uid + " to " + node);
	process_table[uid] = new String(node);
}

// used to make another node receive
// a message
function receive_msg (sender, dest, msg)
{
	var new_server = process_table[dest];
// DEMO
//	alert("received from " + sender);

	send(dest, msg);

	if (new_server != null &&
	    (!(new_server instanceof Process)) &&
	    ((new_server != node_name)))
		sendToServer("send " + sender +" " 
			     + "fix_location("+dest.toSource()+", "
			                      +new_server.toSource()
			                  +")\n");
}

// used to make another node receive
// a process
function receive_process (process)
{
// DEMO
//	alert("received process " + process.toSource());

	process_table[process.uid] = process;
	process_queue.push(process);
}

primops["migrate"] = function () {
	if (this.fn_args.length != 1) {
		print("wrong number of arguments to migrate");
		expr = null;
		return;
	}

	process.expr  = null;
	process.cont  = cont;
	process.env   = scope;
	process.args  = [null];

	var dest = this.fn_args[0].lookup();

// DEMO
//	alert("migrate " + process.toSource() + " to " + dest);

	if (dest != node_name) {
		process_table[process.uid] = new String(dest);

		if (dest != "")
			sendToServer("send " + dest + " "
				     + "receive_process("
				           +process.toSource()
                                           +")\n");
	}
	args.length = 1;
	args[0] = null;
	expr = null;
};

primops["send"] = function () {
	if (this.fn_args.length != 2) {
		print("wrong number of arguments to send");
		expr = null;
		return;
	}

	var receiver = this.fn_args[0].lookup();
	var message  = this.fn_args[1].lookup();

	send(receiver, message);

	args.length = 1;
	args[0] = null;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};


primops["recv"] = function () {
	if (this.fn_args.length != 0) {
		print("wrong number of arguments to recv");
		expr = null;
		return;
	}

	if (process.mailbox.length > 0) {
		args.length = 1;
		args[0] = process.mailbox.shift();

		if (cont.length > 0) {
			var frame = cont.pop();
			scope = frame.env;
			expr  = frame.body;
		} else {
			expr  = null;
		}
	} else {
		process.expr  = expr;
		process.cont  = cont;
		process.env   = scope;
		process.args  = args;
		process.status = true;
		process_queue.push(process);
		
		expr = null;
	}
};

primops["sleep"] = function () {
	if (this.fn_args.length != 1) {
		print("wrong number of arguments to sleep");
		expr = null;
		return;
	}

	var date = new Date();
	date.setTime(date.getTime() 
		     + this.fn_args[0].lookup());

	process.status = date;

	args.length = 1;
	args[0] = null;

	process.expr  = null;
	process.cont  = cont;
	process.scope = scope;
	process.args  = args;
	process_queue.push(process);
	
	expr = null;
};

// only assignment is to globals 
// (~ define, but callable outside
// the toplevel)
primops["set-global!"] = function () {
	if (this.fn_args.length != 2) {
		print("wrong number of arguments to set-global!");
		expr = null;
		return;
	}

	globals[this.fn_args[0].lookup()] = this.fn_args[1].lookup();

	args.length = 1;
	args[0] = null;

	if (cont.length > 0) {
		var frame = cont.pop();
		scope = frame.env;
		expr  = frame.body;
	} else {
		expr  = null;
	}
};

// used to make a node start executing
// an expression
function receive_expr (exp)
{
	process_queue.push(new Process(null, null,
				       [], [],
				       exp, []));
}

// non-switching eval
function __eval (exp)
{
	var old_scope = scope;
	var old_args = args;
	var old_cont = cont;
	var old_expr = expr;
	var old_process = process;

	scope = [];
	args  = [];
	cont  = [];
	expr  = exp;
	process = new Process(-1, null, 
			      [], [], 
			      exp, []);

	try {
		while(expr != null)
			expr.fn();
	} catch (e) {
	}

	var result = args[0];

	process = old_process
	expr = old_expr;
	cont = old_cont;
	args = old_args;
	scope = old_scope;
	
	return result;
}

// normal eval loop
function evaluate (exp)
{
	var old_scope = scope;

	var old_args = args;

	var old_cont = cont;

	var old_expr = expr;

	var old_process = process;

	if (null != exp)
		process_queue.push(new Process(-1, null, 
					       [], [], 
					       exp, []));

	var switch_count;

	for (switch_count = 0; 
	     switch_count < 10
	     && process_queue.length > 0;
	     switch_count++) {

		process = process_queue.shift();

		if (process.status != null) {
			if (process.status instanceof Date
			    && process.status > new Date()) {
				process_queue.push(process);
				continue;
			}
			if (true == process.status
			    && 0 == process.mailbox.length) {
				process_queue.push(process);
				continue;
			}
		}

		process.status = null;

		expr  = process.expr;
		cont  = process.cont;
		args  = process.args;
		scope = process.env;

		// expr may be null -> do a return
		//        a closure -> call the closure
                //          an expr -> execute that expr
		if (expr instanceof ir_closure) {
			expr.invoke([]);
		} else if (null == expr) {
			if (cont.length > 0) {
				var frame = cont.pop();
				scope = frame.env;
				expr  = frame.body;
			} else {
				expr  = null;
			}
		}

		var cycle_cnt;
		
		try {
			for (cycle_cnt = 0; 
			     cycle_cnt < 100 && null != expr;
			     cycle_cnt++)
				expr.fn();

			if (null != expr) { // null -> don't reenqueue
				process.expr  = expr;
				process.cont  = cont;
				process.env   = scope;
				process.args  = args;
				process_queue.push(process);
			}
		} catch (e) {
			process_table[process.uid] = "";
		}
	}

	var result = args[0];

	process = old_process;
	expr = old_expr;
	cont = old_cont;
	args = old_args;
	scope = old_scope;

	if (window != null)
		window.setTimeout(evaluate, 10);

	return result;
}

function time (fn)
{
	var begin = (new Date()).getTime();
	var result = fn();
	print("time " + ((new Date()).getTime() - begin)/1000);

	return result;
}

// following was compiled before hand

// (lambda numbers
//   (let loop ((numbers numbers) (acc 0))
//     (if (null? numbers)
//         acc
//         (loop (cdr numbers) (+ acc (car numbers))))))
globals["+"] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 3, false, new ir_bind([], [0, 1, 2], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_var_scope(2), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 2, 3], [0], new ir_primop("+", [new ir_var_scope(1), new ir_var_scope(3)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2), new ir_var_args(0)]))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0), new ir_lit(0)]))));

// (lambda (acc . args)
//   (if (null? args)
//       (- acc)
//       (let loop ((numbers args) (acc acc))
//         (if (null? numbers)
//             acc
//             (loop (cdr numbers) (- acc (car numbers)))))))
globals["-"] = __eval(new ir_lambda(null, null, 1, true, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_primop("-", [new ir_var_scope(0)]), new ir_bind(null, null, new ir_lambda([], [], 3, false, new ir_bind([], [0, 1, 2], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_var_scope(2), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 2, 3], [0], new ir_primop("-", [new ir_var_scope(1), new ir_var_scope(3)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2), new ir_var_args(0)]))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(1), new ir_var_scope(0)]))))));

// (lambda numbers
//   (let loop ((numbers numbers) (acc 1))
//     (if (null? numbers)
//         acc
//         (loop (cdr numbers) (* acc (car numbers))))))
globals["*"] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 3, false, new ir_bind([], [0, 1, 2], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_var_scope(2), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 2, 3], [0], new ir_primop("*", [new ir_var_scope(1), new ir_var_scope(3)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2), new ir_var_args(0)]))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0), new ir_lit(1)]))));

// (lambda (acc . args)
//   (if (null? args)
//       (/ acc)
//       (let loop ((numbers args) (acc acc))
//         (if (null? numbers)
//             acc
//             (loop (cdr numbers) (/ acc (car numbers)))))))
globals["/"] = __eval(new ir_lambda(null, null, 1, true, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_primop("/", [new ir_var_scope(0)]), new ir_bind(null, null, new ir_lambda([], [], 3, false, new ir_bind([], [0, 1, 2], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_var_scope(2), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 2, 3], [0], new ir_primop("/", [new ir_var_scope(1), new ir_var_scope(3)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2), new ir_var_args(0)]))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(1), new ir_var_scope(0)]))))));

// (lambda (a b) (cons a b))
globals["cons"] = __eval(new ir_lambda(null, null, 2, false, new ir_primop("cons", [new ir_var_args(0), new ir_var_args(1)])));

// (lambda (a) (car a))
globals["car"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("car", [new ir_var_args(0)])));

// (lambda (a) (cdr a))
globals["cdr"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("cdr", [new ir_var_args(0)])));

// (lambda numbers
//   (let loop ((numbers numbers))
//     (cond ((null? numbers)       #t)
//           ((null? (cdr numbers)) #t)
//           (else   (and (<= (car numbers)
//                            (car (cdr numbers)))
//                        (loop (cdr numbers)))))))
globals["<="] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_lit(true), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_lit(true), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(3)]), new ir_bind([0, 1, 2], [0], new ir_primop("<=", [new ir_var_scope(2), new ir_var_scope(3)]), new ir_if_args(0, new ir_bind([0, 1], [], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_args(0)])), new ir_lit(false)))))))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0)]))));

globals["<"] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_lit(true), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_lit(true), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(3)]), new ir_bind([0, 1, 2], [0], new ir_primop("<", [new ir_var_scope(2), new ir_var_scope(3)]), new ir_if_args(0, new ir_bind([0, 1], [], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_args(0)])), new ir_lit(false)))))))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0)]))));

globals[">"] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_lit(true), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_lit(true), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(3)]), new ir_bind([0, 1, 2], [0], new ir_primop(">", [new ir_var_scope(2), new ir_var_scope(3)]), new ir_if_args(0, new ir_bind([0, 1], [], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_args(0)])), new ir_lit(false)))))))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0)]))));

globals[">="] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_lit(true), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_lit(true), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(3)]), new ir_bind([0, 1, 2], [0], new ir_primop(">=", [new ir_var_scope(2), new ir_var_scope(3)]), new ir_if_args(0, new ir_bind([0, 1], [], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_args(0)])), new ir_lit(false)))))))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0)]))));

globals["="] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_lit(true), new ir_bind(null, null, new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_lit(true), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("car", [new ir_var_scope(3)]), new ir_bind([0, 1, 2], [0], new ir_primop("=", [new ir_var_scope(2), new ir_var_scope(3)]), new ir_if_args(0, new ir_bind([0, 1], [], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_args(0)])), new ir_lit(false)))))))))))), new ir_call(new ir_var_args(0), [new ir_var_args(0), new ir_var_scope(0)]))));


// (lambda (a b) (eq? a b))
globals["eq?"] = __eval(new ir_lambda(null, null, 2, false, new ir_primop("eq?", [new ir_var_args(0), new ir_var_args(1)])))

// (lambda (a) (null? a))
globals["null?"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("null?", [new ir_var_args(0)])));

// (lambda (a) (pair? a))
globals["pair?"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("pair?", [new ir_var_args(0)])));

globals["call/cc"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("call/cc", [new ir_var_args(0)])));
globals["call-with-current-continuation"] = globals["call/cc"];

// (lambda lsts
//   (if (null? lsts)
//       '()
//       (let loop ((cur-lst (car lsts))
//                  (lsts    (cdr lsts)))
//         (cond ((null? lsts)
//                cur-lst)
//               ((null? cur-lst)
//                (loop (car lsts)
//                      (cdr lsts)))
//               (else (cons (car cur-lst)
//                           (loop (cdr cur-lst)
//                                 lsts)))))))
// seems bugged :(
// globals["append"] = __eval(new ir_lambda(null, null, 0, true, new ir_bind([], [0], new ir_primop("null?", [new ir_var_scope(0)]), new ir_if_args(0, new ir_lit(null), new ir_bind(null, null, new ir_lambda([], [], 3, false, new ir_bind([], [0, 1, 2], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_var_scope(1), new ir_bind(null, null, new ir_primop("null?", [new ir_var_scope(1)]), new ir_if_args(0, new ir_bind([0, 2], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2), new ir_var_args(0)]))), new ir_bind(null, null, new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1, 2], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 2, 3], [0], new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(3), new ir_var_scope(1)]), new ir_primop("cons", [new ir_var_scope(2), new ir_var_args(0)]))))))))), new ir_bind([0], [0], new ir_primop("car", [new ir_var_scope(0)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(0)]), new ir_call(new ir_var_scope(1), [new ir_var_scope(1), new ir_var_scope(2), new ir_var_args(0)]))))))));

// (lambda (fn arg . args)
//   (apply fn
//          (let loop ((args (cons arg args)))
//            (if (null? (cdr args))
//                (car args)
//                (cons (car args)
//                      (loop (cdr args)))))))
globals["apply"] = __eval(new ir_lambda(null, null, 2, true, new ir_bind([], [0, 1, 2], new ir_lambda([], [], 2, false, new ir_bind([], [0, 1], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("null?", [new ir_var_scope(2)]), new ir_if_args(0, new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [], new ir_primop("car", [new ir_var_scope(1)]), new ir_bind([0, 1], [0], new ir_primop("cdr", [new ir_var_scope(1)]), new ir_bind([0, 2], [0], new ir_call(new ir_var_scope(0), [new ir_var_scope(0), new ir_var_scope(2)]), new ir_primop("cons", [new ir_var_scope(1), new ir_var_args(0)])))))))), new ir_bind([0, 1, 2], [0], new ir_primop("cons", [new ir_var_scope(1), new ir_var_scope(2)]), new ir_bind([0, 3], [0], new ir_call(new ir_var_scope(1), [new ir_var_scope(1), new ir_var_scope(2)]), new ir_primop("apply", [new ir_var_scope(0), new ir_var_args(0)]))))));

globals["print"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("print", [new ir_var_args(0)])));
globals["spawn"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("spawn", [new ir_var_args(0)])));

globals["die"] = __eval(new ir_lambda(null, null, 0, false, new ir_primop("die", [])));

globals["yield"] = __eval(new ir_lambda(null, null, 0, false, new ir_primop("yield", [])));

globals["self"] = __eval(new ir_lambda(null, null, 0, false, new ir_primop("self", [])));
globals["node"] = __eval(new ir_lambda(null, null, 0, false, new ir_primop("node", [])));

globals["migrate"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("migrate", [new ir_var_args(0)])));

globals["send"] = __eval(new ir_lambda(null, null, 2, false, new ir_primop("send", [new ir_var_args(0), new ir_var_args(1)])));

globals["recv"] = __eval(new ir_lambda(null, null, 0, false, new ir_primop("recv", [])));

globals["sleep"] = __eval(new ir_lambda(null, null, 1, false, new ir_primop("sleep", [new ir_var_args(0)])));

globals["set-global!"] = __eval(new ir_lambda(null, null, 2, false, new ir_primop("set-global!", [new ir_var_args(0), new ir_var_args(1)])));
