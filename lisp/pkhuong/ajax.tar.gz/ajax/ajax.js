// File: "ajax.js"

// Author: Marc Feeley (March 18, 2007)

var ajax_channel_id = false; // channel identifier on the server

function ajax_setup(channel_id) {
  ajax_channel_id = channel_id;
  ajax_wait_for_input();
}

function ajax_wait_for_input() {
  ajax_request(ajax_channel_id+"/s2c", "", ajax_input_handler);
}

function ajax_input_handler(content) {
  ajax_add_input(content);
  ajax_wait_for_input();
}

function ajax_request(url, content, handler) {
  var req;
  if (window.XMLHttpRequest) { // Mozilla, Safari, ...
    req = new XMLHttpRequest();
    if (req.overrideMimeType) {
      req.overrideMimeType("text/xml");
    }
  } else if (window.ActiveXObject) { // IE
    try {
      req = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch (e) {
      try {
        req = new ActiveXObject("Microsoft.XMLHTTP");
      }
      catch (e) {
      }
    }
  }
  if (!req) {
    alert("Giving up (cannot create an XMLHTTP instance)");
    return false;
  }
  if (handler == null) {
    req.open("POST", url, false); // synchronous request
  } else {
    req.onreadystatechange =
      function() {
        if (req.readyState == 4) {
          if (req.status == 200) {
            handler(req.responseText);
          } else {
            alert("There was a problem with the request");
          }
        }
      };
    req.open("POST", url, true); // asynchronous request
  }
  req.send(content);
  return req;
}

function ajax_syntax_error() {
  return undefined;
}

function ajax_is_syntax_error(obj) {
  return typeof obj == typeof undefined;
}

function ajax_deserialize(str) {

  var end = str.length;
  var pos = 0;

  function advance() {
    pos++;
  }

  function peek_char() {
    if (pos < end)
      return str.charCodeAt(pos);
    return -1;
  }

  function peek_non_whitespace() {
    while (pos < end && str.charCodeAt(pos) <= 32) advance();
    return peek_char();
  }

  function read_string() {
    var a = new Array();
    var i = pos;
    while (pos < end) {
      var c = str.charCodeAt(pos);
      if (c == 34) { // "
        if (i < pos)
          a.push(str.substring(i, pos));
        advance();
        return a.join("");
      } else if (c == 92) { // \
        if (i < pos)
          a.push(str.substring(i, pos));
        advance();
        switch (c = peek_char()) {
          case -1:
            return ajax_syntax_error();
          case 110: // n
            a.push(String.fromCharCode(10));
            break;
          case 114: // r
            a.push(String.fromCharCode(13));
            break;
          default:
            a.push(String.fromCharCode(c));
            break;
        }
        advance();
        i = pos;
      } else {
        advance();
      }
    }
    return ajax_syntax_error();
  }

  function read_object() {
    switch (peek_non_whitespace()) {
      case 34: // "
        advance();
        return read_string();
      default:
        // TODO: add other types
        return ajax_syntax_error();
    }
  }

  var obj = read_object();

  if (pos == end)
    return obj;

  return ajax_syntax_error();
}

function ajax_serialize(obj) {

  var output = new Array();

  function write_string(str) {
    var i = 0;
    var j;
    output.push('"');
    for (j=0; j<str.length; j++) {
      var c = str.charCodeAt(j);
      if (c == 10) { // LF
        if (i < j) output.push(str.substring(i, j));
        i = j+1;
        output.push('\\n');
      } else if (c == 13) { // CR
        if (i < j) output.push(str.substring(i, j));
        i = j+1;
        output.push('\\r');
      } else if (c == 34) { // "
        if (i < j) output.push(str.substring(i, j));
        i = j+1;
        output.push('\\"');
      } else if (c == 92) { // \
        if (i < j) output.push(str.substring(i, j));
        i = j+1;
        output.push('\\\\');
      }
    }
    if (i < j) output.push(str.substring(i, j));
    output.push('"');
  }

  function write_object(obj) {
    if (typeof obj == "String" ||
        typeof obj == "string") {
      write_string(obj);
    }
    // TODO: add other types
  }

  write_object(obj);

  return output.join("");
}

function ajax_add_input(str) {
  var obj = ajax_deserialize(str);
  z_current_console.write_string(obj);
}

function ajax_add_output(obj) {
  ajax_request(ajax_channel_id+"/c2s", ajax_serialize(obj), null);
}
