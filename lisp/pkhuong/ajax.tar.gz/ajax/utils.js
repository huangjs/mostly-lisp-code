// File: "utils.js"

// Author: Marc Feeley (March 18, 2007)

function get(id) {
  return document.getElementById(id).innerHTML;
}

function set(id, content) {
  document.getElementById(id).innerHTML = content;
}

function add(id, content) {
  set(id, get(id) + content);
}
