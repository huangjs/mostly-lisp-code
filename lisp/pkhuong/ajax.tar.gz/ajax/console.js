// File: "console.js"

// Author: Marc Feeley (March 18, 2007)

function z_char_to_html(c)
{
  if (c == 10 || c == 13)
    return "<br>"
  if (c == 32)
    return "&nbsp;"
  return "&#" + c + ";"
}

function z_string_to_html(str)
{
  var output = new Array()
  var i
  for (i=0; i<str.length; i++)
    output.push(z_char_to_html(str.charCodeAt(i)))
  return output.join("")
}

function z_insert_child_at(parent, index, child)
{
  if (index !== false)
    {
      var c = z_child_at(parent, index);
      if (c)
        {
          parent.insertBefore(child, c)
          return
        }
    }
  parent.appendChild(child)
}

function z_child_at(parent, index)
{
  var c = parent.firstChild
  var i = 0
  while (c && i != index)
    {
      c = c.nextSibling
      i++
    }
  if (c)
    return c
  return false
}

function z_child_index(child)
{
  var c = child.parentNode.firstChild
  var i = 0
  while (c && c !== child)
    {
      c = c.nextSibling
      i++
    }
  if (c)
    return i
  return false
}

function z_get_pos(elem)
{
  return { x: elem.offsetLeft,
           y: elem.offsetTop }
}

function z_view_size(wind)
{
  if (wind.innerHeight !== undefined) // only IE does not support innerHeight
    return { x: wind.innerWidth,
             y: wind.innerHeight }

  var doc = wind.document
  var de = doc.documentElement

  if (de && de.clientHeight) // IE in strict mode
    return { x: de.clientWidth,
             y: de.clientHeight }

  var db = doc.body

  if (db) // other IE
    return { x: db.clientWidth,
             y: db.clientHeight }

  return { x: 100, y: 100 }
}

function z_view_offset(wind)
{
  if (wind.pageYOffset !== undefined) // only IE does not support pageYOffset
    return { x: wind.pageXOffset,
             y: wind.pageYOffset }

  var doc = wind.document
  var de = doc.documentElement

  if (de && de.scrollTop) // IE in strict mode
    return { x: de.scrollLeft,
             y: de.scrollTop }

  var db = doc.body

  if (db) // other IE
    return { x: db.scrollLeft,
             y: db.scrollTop }

  return { x: 0, y: 0 }
}

function z_get_frame_window(frame_id)
{
  var wind
  if (window.frames && window.frames[frame_id]) // IE5, Konq, Safari
    wind = window.frames[frame_id]
  else
    {
      var elem = document.getElementById(frame_id)
      if (elem.contentWindow) // IE5.5+, Moz 1.0+, Opera
        wind = elem.contentWindow
      else // Moz < 0.9 (Netscape 6.0)
        wind = elem
    }
  return wind
} 

function z_get_frame_document(frame_id)
{ 
  var wind = z_get_frame_window(frame_id)
  var doc = wind.document
  if (!doc)
    doc = wind.contentDocument
  // Moz 0.9+, Konq, Safari, IE, Opera||Moz < 0.9 (NS 6.0) 
  return doc
}

function z_get_document(ifrm)
{
  if (ifrm.contentWindow) // IE5.5+
    return ifrm.contentWindow.document

  if (ifrm.contentDocument) // NS6
    return ifrm.contentDocument

  if (ifrm.document) // IE5
   return ifrm.document

  return null
}

function z_get_window(ifrm)
{
  if (ifrm.contentWindow) // IE5.5+
    return ifrm.contentWindow

  return frames[ifrm.id]
}

var z_ic = null

function z_input_controller()
{
  var keydown = 0
  var keypress = 1
  var keyup = 2

  var keydown_code = -1
  var keydown_processed = false
  var input_handler = null

  function set_input_handler(ih)
  {
    if (input_handler)
      input_handler.handle_blur()
    input_handler = ih
    if (input_handler)
      input_handler.handle_focus()
  }

  function make_key_handler(type)
  {
    function handler(e)
    {
      if (!e) e = window.event

      var code = e.keyCode
      if (!code) code = e.which

      switch (type)
        {
          case keydown:
            if ((code >= 1 && code <= 31) ||    // backspace/tab/enter/...
                (code >= 33 && code <= 40) ||   // pgup/pgdn/end/home/arrows
                (code >= 45 && code <= 46) ||   // ins/del
                (code >= 112 && code <= 123))   // F1/.../F12
              {
                keydown_code = code
                keydown_processed = true
                input_handler.handle_key(keydown_code,keydown_code)
              }
            else
              keydown_code = -1
            break

          case keypress:
            if (input_handler)
              {
                if (keydown_code >= 0)
                  {
                    if (keydown_processed)
                      keydown_processed = false
                    else
                      input_handler.handle_key(keydown_code,keydown_code)
                  }
                else if (code < 128) // IE generates a keypress of 191 on /
                  {
                    if (e.ctrlKey)
                      {
                        if (code >= 64 && code <= 95)
                          code = code - 64
                        else if (code >= 96 && code <= 127)
                          code = code - 96
                        else if (code == 32)
                          code = 0
                        else if (code > 32)
                          code = -1
                      }
                    if (code >= 0)
                      input_handler.handle_key(code,keydown_code)
                  }
              }
            break
        }

      if (e.stopPropagation)
        e.stopPropagation()
      e.cancelBubble = true

      if (type == keydown && keydown_code < 0)
        return true
      else
        return false
    }

    return handler
  }

  this.set_input_handler = set_input_handler
  this.onkeydown = make_key_handler(keydown)
  this.onkeypress = make_key_handler(keypress)
  this.onkeyup = make_key_handler(keyup)
}

function z_console(iframe_id)
{
  var console = this

  function create_htmlelement()
  {
    var htmlelement = frames[iframe_id]
    if (!htmlelement)
      htmlelement = document.getElementById(iframe_id)
    htmlelement = z_get_frame_window(iframe_id)
    z_set_widget(htmlelement, console)
    console.htmlelement = htmlelement

    var doc = z_get_document(htmlelement)

    doc.open('text/html')
    doc.write('<html><style type="text/css">')
    doc.write('body { font-family: monospace; font-size: 10pt; border: 0px; margin: 0px; padding: 3px; background-color: #dee7ec; }')
    doc.write('.z_out { font-weight: normal; }')
    doc.write('.z_in { font-weight: bold; }')
    doc.write('#z_cursor { background: black; color: white; }')
    doc.write('</style>')
    doc.write('<body></body></html>')
    doc.close()

    var cursor = doc.createElement("span")
    cursor.id = "z_cursor"
    cursor.className = "z_in"
    cursor.char_code = 32
    cursor.innerHTML = "&nbsp;"
    cursor.onclick = handle_click
    doc.body.appendChild(cursor)

    console.cursor = cursor
    console.marker = null

    var end =   doc.createElement("span")
    end.innerHTML = "&nbsp;"
    doc.body.appendChild(end)

    doc.onclick = function() { z_ic.set_input_handler(console); return false; }
  }

  function handle_key(code, keydown_code)
  {
    if (keydown_code >= 0)
      handle_special_key(keydown_code)
    else
      handle_char(code)
  }

  function handle_char(c)
  {
    switch (c)
      {
        case 8:
        case 10:
        case 13:
          handle_special_key(c)
          break

        case 1: // ctrl-a
          move_cursor(start_of_input_line())
          break

        case 2: // ctrl-b
          move_cursor(before_cursor())
          break

        case 3: // ctrl-c
          if (user_interrupt)
            user_interrupt()
          break

        case 4: // ctrl-d
          delete_char(at_cursor())
          break

        case 5: // ctrl-e
          move_cursor(end_of_input_line())
          break

        case 6: // ctrl-f
          move_cursor(after_cursor())
          break

        default:
          if (c >= 32)
            insert_char_before_cursor(c)
          break
      }
  }

  function handle_click(e)
  {
    if (!e) e = window.event

    var t = e.target
    if (!t) t = e.srcElement
    if (t.nodeType == 3) t = t.parentNode

    move_cursor(t)

    console.handle_select()
  }

  function html_to_span(html)
  {
    var doc = z_get_document(console.htmlelement)
    var s = doc.createElement("span")
    s.innerHTML = html
    return s
  }

  function char_to_span(c)
  {
    return html_to_span(z_char_to_html(c))
  }

  function insert_char_before(c, elem)
  {
    var s = char_to_span(c)
    elem.parentNode.insertBefore(s, elem)
    return s
  }

  function insert_html_before(html, elem)
  {
    var s = html_to_span(html)
    elem.parentNode.insertBefore(s, elem)
    return s
  }

  function insert_html_after(html, elem)
  {
    var s = html_to_span(html)
    if (elem.nextSibling)
      elem.parentNode.insertBefore(s, elem.nextSibling)
    else
      elem.parentNode.appendChild(s)
    return s
  }

  function insert_char_before_cursor(c)
  {
    var s = insert_char_before(c, console.cursor)
    s.char_code = c
    s.className = console.cursor.className
    s.onclick = handle_click
    update_cursor()
    return s
  }

  function write(html)
  {
    var s
    if (console.marker)
      s = insert_html_after(html, console.marker)
    else
      s = insert_html_before(html, console.cursor.parentNode.firstChild)
    s.className = "z_out"
    console.marker = s
    update_cursor()
  }

  function write_char(c)
  {
    write(z_char_to_html(c))
  }

  function write_string(str)
  {
    write(z_string_to_html(str))
  }

  function delete_char(t)
  {
    if (t)
      {
        if (t === console.cursor)
          {
            var next = t.nextSibling
            console.cursor.id = null
            console.cursor = null
            t.parentNode.removeChild(t)
            move_cursor(next)
          }
        else
          {
            t.parentNode.removeChild(t)
            update_cursor()
          }
      }
  }

  function handle_special_key(keydown_code)
  {
    switch (keydown_code)
      {
        case 8:
          delete_char(before_cursor())
          break

        case 9:
          break

        case 10:
        case 13:
          {
            var input = get_input()
            if (console.read_line)
              console.read_line(input)
            break
          }

        case 37: // <-
          move_cursor(before_cursor())
          break

        case 38: // ^
          break

        case 39: // ->
          move_cursor(after_cursor())
          break

        case 40: // v
          break
      }
  }

  function move_cursor(t)
  {
    if (t && t !== console.cursor)
      {
        if (console.cursor)
          console.cursor.id = null
        console.cursor = t
        console.cursor.id = "z_cursor"
        update_cursor()
      }
  }

  function before_cursor()
  {
    var p = console.cursor
    if (p.previousSibling && p.previousSibling.char_code)
      return p.previousSibling
    return null
  }

  function at_cursor()
  {
    if (console.cursor.nextSibling && console.cursor.nextSibling.char_code)
      return console.cursor
    return null
  }

  function after_cursor()
  {
    var p = console.cursor
    if (p.nextSibling && p.nextSibling.char_code)
      return p.nextSibling
    return null
  }

  function start_of_input_line()
  {
    var p = console.cursor
    while (p.previousSibling && p.previousSibling.char_code)
      p = p.previousSibling
    return p
  }

  function end_of_input_line()
  {
    var p = console.cursor
    while (p.nextSibling && p.nextSibling.char_code)
      p = p.nextSibling
    return p
  }

  function get_input()
  {
    var input = new Array()
    var p = console.marker
    if (!p)
      p = console.cursor.parentNode.firstChild
    while (p.nextSibling && p.nextSibling.char_code)
      {
        if (p.char_code)
          input.push(String.fromCharCode(p.char_code))
        p.char_code = false
        p.onclick = null
        p = p.nextSibling
      }
    console.marker = insert_char_before(10, p)
    move_cursor(p)
    update_cursor()
    return input.join("")
  }

  function scroll_into_view(elem)
  {
    var wind = console.htmlelement
    if (wind.id)
      wind = z_get_frame_window(wind.id)
    var v = z_view_size(wind)
    var o = z_view_offset(wind)
    var p = z_get_pos(elem)

    var x = p.x - o.x
    var y = p.y - o.y

    v.x -= 15 // account for possible scrollbars
    v.y -= 15

    if (x < 0)
      x = p.x - (v.x>>2)
    else if (x+12 > v.x)
      x = p.x - (v.x-(v.x>>2))
    else
      x = o.x

    if (y < 0)
      y = p.y - (v.y>>2)
    else if (y+24 > v.y)
      y = p.y - (v.y-(v.y>>2))
    else
      y = o.y

    wind.scrollTo(x,y)
  }

  function update_cursor()
  {
    scroll_into_view(console.cursor)
  }

  function handle_focus()
  {
    console.cursor.id = "z_cursor"
    console.cursor.innerHTML = console.cursor.innerHTML
  }

  function handle_blur()
  {
    console.cursor.id = null
    console.cursor.innerHTML = console.cursor.innerHTML
  }

  function handle_select()
  {
    z_ic.set_input_handler(console)
  }

  create_htmlelement()

  console.write = write
  console.write_char = write_char
  console.write_string = write_string
  console.read_line = null
  console.user_interrupt = null
  console.handle_key = handle_key
  console.handle_focus = handle_focus
  console.handle_blur = handle_blur
  console.handle_select = handle_select

  z_ic.set_input_handler(console)
}

var z_current_console = null

function z_create_console(tabgroup, index, title)
{
  var tab = new z_tab(tabgroup, index, title)
  var console = tab.console

  z_current_console = console

  console.read_line = function(input) { }

  return console
}

function z_setup()
{
  z_ic = new z_input_controller()
  document.onkeydown = z_ic.onkeydown
  document.onkeypress = z_ic.onkeypress
  document.onkeyup = z_ic.onkeyup

  z_tg = new z_tabgroup(document, document.body, true)
}

function z_dump(obj,indent)
{
  var n = 0
  var prop = null
  for (prop in obj) n++
  if (typeof(obj) == "String" ||
      typeof(obj) == "string" ||
      n == 0)
    return "" + obj + "\n"
  var str = indent + "[" + typeof(obj)
  for (prop in obj)
    {
      var x = obj[prop]
      if (typeof(x) == "String" || typeof(x) == "string")
         x = '"' + x + '"'
      else if (typeof(x) == "function")
         x = "[function]"
      str = str + "\n" + indent + "  " + prop + ": " + x
    }
  str = str + "\n]\n"
  return str
}

function pp(obj)
{
  var str = z_dump(obj,"")
  z_current_console.write_string(str)
}

var z_iframe_counter = 0

function z_append_child_iframe(doc, parent)
{
  var iframe_id = "z_iframe_" + z_iframe_counter++
  var iframe = false
  var iframe_doc = false

  try
    {
      iframe = doc.createElement("iframe")
      iframe.id = iframe_id
      iframe.style.border = "0px"
      iframe.style.width = "100%"
      iframe.style.height = "80%"

      parent.appendChild(iframe)

      if (doc.frames)
        {
          // this is for IE5 Mac, because it will only
          // allow access to the document object
          // of the IFrame if we access it through
          // the document.frames array
          iframe = doc.frames[iframe_id]
        }
    }
  catch(exc)
    {
      // This is for IE5 PC, which does not allow dynamic creation
      // and manipulation of an iframe object. Instead, we'll fake
      // it up by creating our own objects.
      alert("failure")
      iframeHTML = '\<iframe id="RSIFrame'+iframe_counter+'" style="';
      iframeHTML+='border:0px;';
      iframeHTML+='width:10px;';
      iframeHTML+='height:10px;';
      iframeHTML+='">foo<\/iframe>';
      document.body.innerHTML+=iframeHTML;
      IFrameObj = new Object();
      IFrameObj.document = new Object();
      IFrameObj.document.location = new Object();
      IFrameObj.document.location.iframe = document.getElementById('RSIFrame'+iframe_counter);
      IFrameObj.document.location.replace =
        function(location) { this.iframe.src = location }
    }

  if (iframe.contentDocument)
    {
      // For NS6
      iframe_doc = iframe.contentDocument
    }
  else if (iframe.contentWindow)
    {
      // For IE5.5 and IE6
      iframe_doc = iframe.contentWindow.document
    }
  else if (iframe.document)
    {
      // For IE5
      iframe_doc = iframe.document
    }
  else
    {
      return false
    }

  iframe_doc.open("text/html")
  iframe_doc.write('<html><style type="text/css">')
  iframe_doc.write('body { font-family: monospace; font-size: 10pt; border: 0px; margin: 0px; padding: 3px; }')
  iframe_doc.write('.z_out { font-weight: normal; }')
  iframe_doc.write('.z_in { font-weight: bold; }')
  iframe_doc.write('#z_cursor { background: black; color: white; }')
  iframe_doc.write('</style>')
  iframe_doc.write('<body>hello</body></html>')
  iframe_doc.close()

  return iframe_id
}

function z_get_widget(htmlelement)
{
  return htmlelement.z_widget
}

function z_set_widget(htmlelement, widget)
{
  htmlelement.z_widget = widget
}

function z_tab(tabgroup, index, title)
{
  var tab = this

  function create_htmlelement()
  {
    var htmlelement = tab.doc.createElement("li")
    htmlelement.className = "plain"
    z_set_widget(htmlelement, tab)
    z_insert_child_at(tab.tabgroup.tabs, index, htmlelement)
    tab.htmlelement = htmlelement

    var a = tab.doc.createElement("a")
    a.href = ""
    a.onclick = click_handler
    a.innerHTML = z_string_to_html(title)
    htmlelement.appendChild(a)

    var content = tab.doc.createElement("div")
    content.className = "z_hide"
    tab.tabgroup.content.appendChild(content)
    tab.content = content

    var iframe_id = z_append_child_iframe(tab.doc, content)
    var console = new z_console(iframe_id)
    tab.console = console
    console.tab = tab
  }

  function handle_select()
  {
    if (tab.tabgroup.selected)
      {
        tab.tabgroup.selected.htmlelement.className = "plain"
        z_get_widget(tab.tabgroup.selected.htmlelement).content.className = "z_hide"
      }
    tab.htmlelement.className = "selected"
    tab.content.className = "z_show"
    tab.tabgroup.selected = tab

    tab.console.handle_select()
  }

  function click_handler(e)
  {
    tab.handle_select()
    return false
  }

  tab.doc = tabgroup.doc
  tab.tabgroup = tabgroup
  tab.handle_select = handle_select

  create_htmlelement()
}

function z_tabgroup(doc, parent, tabs_at_top)
{
  var tabgroup = this

  function create_htmlelement()
  {
    var htmlelement = tabgroup.doc.createElement("div")
    z_set_widget(htmlelement, tabgroup)
    parent.appendChild(htmlelement)

    var content = tabgroup.doc.createElement("div")
    content.className = "z_tab_content"

    if (!tabs_at_top)
      htmlelement.appendChild(content)

    tabs = tabgroup.doc.createElement("ul")
    tabs.className = (tabs_at_top ? "z_tabgroup_top" : "z_tabgroup_bot")
    htmlelement.appendChild(tabs)

    if (tabs_at_top)
      htmlelement.appendChild(content)

    tabgroup.htmlelement = htmlelement
    tabgroup.content = content
    tabgroup.tabs = tabs
  }

  tabgroup.doc = document
  tabgroup.selected = false

  create_htmlelement()

  var c1 = z_create_console(tabgroup, 0, "CONSOLE")
  c1.tab.handle_select()
}
